#!/usr/bin/env perl

print "Status: 200\n\n$ENV{QUERY_STRING}"
